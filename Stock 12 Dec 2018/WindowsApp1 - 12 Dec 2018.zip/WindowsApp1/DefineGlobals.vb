﻿Public Module DefineGlobals
	Public symbol As String
End Module
