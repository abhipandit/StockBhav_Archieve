﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Premium_Decay
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
		Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
		Me.RadioButton1 = New System.Windows.Forms.RadioButton()
		Me.RadioButton2 = New System.Windows.Forms.RadioButton()
		Me.BhavcopyDataSet = New WindowsApp1.bhavcopyDataSet()
		Me.BhavcopyDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
		Me.FobhavcopyBindingSource = New System.Windows.Forms.BindingSource(Me.components)
		Me.BhavcopyDataSet1 = New WindowsApp1.bhavcopyDataSet1()
		Me.Fo_bhavcopyTableAdapter = New WindowsApp1.bhavcopyDataSet1TableAdapters.fo_bhavcopyTableAdapter()
		Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
		Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
		Me.ComboBox1 = New System.Windows.Forms.ComboBox()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.ComboBox2 = New System.Windows.Forms.ComboBox()
		Me.ComboBox3 = New System.Windows.Forms.ComboBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		CType(Me.BhavcopyDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.BhavcopyDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.FobhavcopyBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.BhavcopyDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.FillByToolStrip.SuspendLayout()
		Me.SuspendLayout()
		'
		'DateTimePicker1
		'
		Me.DateTimePicker1.Location = New System.Drawing.Point(124, 38)
		Me.DateTimePicker1.Name = "DateTimePicker1"
		Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
		Me.DateTimePicker1.TabIndex = 0
		'
		'DateTimePicker2
		'
		Me.DateTimePicker2.Location = New System.Drawing.Point(438, 39)
		Me.DateTimePicker2.Name = "DateTimePicker2"
		Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
		Me.DateTimePicker2.TabIndex = 1
		'
		'RadioButton1
		'
		Me.RadioButton1.AutoSize = True
		Me.RadioButton1.Checked = True
		Me.RadioButton1.Location = New System.Drawing.Point(124, 77)
		Me.RadioButton1.Name = "RadioButton1"
		Me.RadioButton1.Size = New System.Drawing.Size(46, 17)
		Me.RadioButton1.TabIndex = 2
		Me.RadioButton1.TabStop = True
		Me.RadioButton1.Text = "Nifty"
		Me.RadioButton1.UseVisualStyleBackColor = True
		'
		'RadioButton2
		'
		Me.RadioButton2.AutoSize = True
		Me.RadioButton2.Location = New System.Drawing.Point(124, 115)
		Me.RadioButton2.Name = "RadioButton2"
		Me.RadioButton2.Size = New System.Drawing.Size(53, 17)
		Me.RadioButton2.TabIndex = 3
		Me.RadioButton2.Text = "Stock"
		Me.RadioButton2.UseVisualStyleBackColor = True
		'
		'BhavcopyDataSet
		'
		Me.BhavcopyDataSet.DataSetName = "bhavcopyDataSet"
		Me.BhavcopyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
		'
		'BhavcopyDataSetBindingSource
		'
		Me.BhavcopyDataSetBindingSource.DataSource = Me.BhavcopyDataSet
		Me.BhavcopyDataSetBindingSource.Position = 0
		'
		'FobhavcopyBindingSource
		'
		Me.FobhavcopyBindingSource.DataMember = "fo_bhavcopy"
		Me.FobhavcopyBindingSource.DataSource = Me.BhavcopyDataSet1
		'
		'BhavcopyDataSet1
		'
		Me.BhavcopyDataSet1.DataSetName = "bhavcopyDataSet1"
		Me.BhavcopyDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
		'
		'Fo_bhavcopyTableAdapter
		'
		Me.Fo_bhavcopyTableAdapter.ClearBeforeFill = True
		'
		'FillByToolStrip
		'
		Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FillByToolStripButton})
		Me.FillByToolStrip.Location = New System.Drawing.Point(0, 0)
		Me.FillByToolStrip.Name = "FillByToolStrip"
		Me.FillByToolStrip.Size = New System.Drawing.Size(800, 25)
		Me.FillByToolStrip.TabIndex = 5
		Me.FillByToolStrip.Text = "FillByToolStrip"
		'
		'FillByToolStripButton
		'
		Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
		Me.FillByToolStripButton.Name = "FillByToolStripButton"
		Me.FillByToolStripButton.Size = New System.Drawing.Size(39, 22)
		Me.FillByToolStripButton.Text = "FillBy"
		'
		'ComboBox1
		'
		Me.ComboBox1.FormattingEnabled = True
		Me.ComboBox1.Location = New System.Drawing.Point(183, 115)
		Me.ComboBox1.Name = "ComboBox1"
		Me.ComboBox1.Size = New System.Drawing.Size(141, 21)
		Me.ComboBox1.TabIndex = 6
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(311, 214)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(103, 23)
		Me.Button1.TabIndex = 7
		Me.Button1.Text = "Calculate Decay"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'ComboBox2
		'
		Me.ComboBox2.FormattingEnabled = True
		Me.ComboBox2.Location = New System.Drawing.Point(350, 115)
		Me.ComboBox2.Name = "ComboBox2"
		Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
		Me.ComboBox2.TabIndex = 8
		'
		'ComboBox3
		'
		Me.ComboBox3.FormattingEnabled = True
		Me.ComboBox3.Location = New System.Drawing.Point(183, 77)
		Me.ComboBox3.Name = "ComboBox3"
		Me.ComboBox3.Size = New System.Drawing.Size(200, 21)
		Me.ComboBox3.TabIndex = 9
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(62, 39)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(56, 13)
		Me.Label1.TabIndex = 10
		Me.Label1.Text = "From Date"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(376, 39)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(46, 13)
		Me.Label2.TabIndex = 11
		Me.Label2.Text = "To Date"
		'
		'Premium_Decay
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(800, 450)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.ComboBox3)
		Me.Controls.Add(Me.ComboBox2)
		Me.Controls.Add(Me.Button1)
		Me.Controls.Add(Me.ComboBox1)
		Me.Controls.Add(Me.FillByToolStrip)
		Me.Controls.Add(Me.RadioButton2)
		Me.Controls.Add(Me.RadioButton1)
		Me.Controls.Add(Me.DateTimePicker2)
		Me.Controls.Add(Me.DateTimePicker1)
		Me.Name = "Premium_Decay"
		Me.Text = "Premium_Decay"
		CType(Me.BhavcopyDataSet, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.BhavcopyDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.FobhavcopyBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.BhavcopyDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.FillByToolStrip.ResumeLayout(False)
		Me.FillByToolStrip.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents DateTimePicker1 As DateTimePicker
	Friend WithEvents DateTimePicker2 As DateTimePicker
	Friend WithEvents RadioButton1 As RadioButton
	Friend WithEvents RadioButton2 As RadioButton
	Friend WithEvents BhavcopyDataSet As bhavcopyDataSet
	Friend WithEvents BhavcopyDataSetBindingSource As BindingSource
	Friend WithEvents BhavcopyDataSet1 As bhavcopyDataSet1
	Friend WithEvents FobhavcopyBindingSource As BindingSource
	Friend WithEvents Fo_bhavcopyTableAdapter As bhavcopyDataSet1TableAdapters.fo_bhavcopyTableAdapter
	Friend WithEvents FillByToolStrip As ToolStrip
	Friend WithEvents FillByToolStripButton As ToolStripButton
	Friend WithEvents ComboBox1 As ComboBox
	Friend WithEvents Button1 As Button
	Friend WithEvents ComboBox2 As ComboBox
	Friend WithEvents ComboBox3 As ComboBox
	Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
End Class
