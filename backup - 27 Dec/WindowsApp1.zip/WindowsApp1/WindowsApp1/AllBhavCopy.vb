﻿Imports System.Configuration
Imports System.Data.SqlClient

Imports Excel = Microsoft.Office.Interop.Excel          ' EXCEL APPLICATION.

Public Class AllBhavCopy
	Dim xlApp As Excel.Application
	Dim xlWorkBook As Excel.Workbook
	Dim xlWorkSheet As Excel.Worksheet

	Dim downloadpath = Environment.ExpandEnvironmentVariables("%USERPROFILE%\Downloads") & "\stock_files"
	Dim app_con_str = ConfigurationManager.ConnectionStrings("WindowsApp1.My.MySettings.bhavcopyConnectionString").ConnectionString

	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
		Dim totalDays = DateDiff(DateInterval.Day, DateTimePicker1.Value, DateTimePicker2.Value) + 1

		Dim startDate = DateTimePicker1.Value
		Dim currDate = startDate

		Dim con_chk As New SqlConnection
		con_chk.ConnectionString = app_con_str
		con_chk.Open()

		For i As Integer = 1 To totalDays

			If Not (currDate.DayOfWeek = DayOfWeek.Saturday Or currDate.DayOfWeek = DayOfWeek.Sunday) Then

				Dim day_val = ""
				If currDate.Day < 10 Then
					day_val = "0" & currDate.Day
				Else
					day_val = currDate.Day
				End If

				Dim file_name_1 = "cm" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"
				Dim file_name_2 = currDate.Year & "/" & MonthName(currDate.Month, True).ToUpper() & "/cm" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"

				Dim cmd_chk_1 As New SqlCommand
				cmd_chk_1.Connection = con_chk
				cmd_chk_1.CommandText = "select count(*) as t1 From bhavcopy where cast(TIMESTAMP as date)= '" & currDate & "'"
				If cmd_chk_1.ExecuteScalar = 0 Then
					Form1.DownloadBhavCopy(file_name_1, file_name_2, currDate)
				End If



				Dim dat_name_1 = "MTO_" & day_val & currDate.Month & currDate.Year & ".DAT"
				Dim cmd_chk_2 As New SqlCommand
				cmd_chk_2.Connection = con_chk
				cmd_chk_2.CommandText = "select count(*) From Delivery_Position where cast(TIMESTAMP as date)= '" & currDate & "'"
				If cmd_chk_2.ExecuteScalar = 0 Then
					Form1.DownloadSecurityDat(dat_name_1, dat_name_1, currDate)
				End If

				Dim vol_name_1 = "CMVOLT_" & day_val & currDate.Month & currDate.Year & ".CSV"
				Dim cmd_chk_3 As New SqlCommand
				cmd_chk_3.Connection = con_chk
				cmd_chk_3.CommandText = "select count(*) From CMVOLT where cast(TIMESTAMP as date)= '" & currDate & "'"
				If cmd_chk_3.ExecuteScalar = 0 Then
					Form1.DownloadVolt(vol_name_1, vol_name_1, currDate)
				End If

				Dim fobhavcopy_1 = "fo" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"
				Dim fobhavcopy_2 = currDate.Year & "/" & MonthName(currDate.Month, True).ToUpper() & "/fo" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"


				Dim cmd_chk_4 As New SqlCommand
				cmd_chk_4.Connection = con_chk
				cmd_chk_4.CommandText = "select count(*) From fo_bhavcopy where cast(TIMESTAMP as date)= '" & currDate & "'"
				If cmd_chk_4.ExecuteScalar = 0 Then
					Form1.DownloadFOCopy(fobhavcopy_1, fobhavcopy_2, currDate)
				End If

				Dim indClose_1 = "ind_close_all_" & day_val & currDate.Month & currDate.Year & ".csv"
				Dim cmd_chk_5 As New SqlCommand
				cmd_chk_5.Connection = con_chk
				cmd_chk_5.CommandText = "select count(*) From index_close where cast(index_date as date)= '" & currDate & "'"
				If cmd_chk_5.ExecuteScalar = 0 Then
					Form1.DownloadIndexClose(indClose_1, indClose_1, currDate)
				End If

			End If
			currDate = DateAdd("d", 1, currDate)
		Next

		MsgBox("Downloaded All BhavCopy")

	End Sub

	Private Sub AllBhavCopy_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		DateTimePicker2.Value = Today
		DateTimePicker1.Value = DateAdd("d", -365, DateTimePicker2.Value)
	End Sub
End Class