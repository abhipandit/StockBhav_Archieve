﻿Imports System.IO
Imports System.Data.SqlClient

Imports Excel = Microsoft.Office.Interop.Excel          ' EXCEL APPLICATION.
Imports System.Configuration

Public Class Premium_Decay
	Dim xlApp As Excel.Application
	Dim xlWorkBook As Excel.Workbook
	Dim xlWorkSheet As Excel.Worksheet
	Dim app_con_str = ConfigurationManager.ConnectionStrings("WindowsApp1.My.MySettings.bhavcopyConnectionString").ConnectionString

	Private Sub Premium_Decay_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		Dim myConn As New SqlConnection(app_con_str)
		myConn.Open()
		Dim da As New SqlDataAdapter("select distinct(symbol) as t1 from fo_bhavcopy", myConn)
		Dim dt As New DataTable
		da.Fill(dt)

		ComboBox1.ValueMember = "t1"
		ComboBox1.DisplayMember = "t1"
		ComboBox1.DataSource = dt

		Dim da1 As New SqlDataAdapter("select distinct(index_name) as t1 from index_close", myConn)
		Dim dt1 As New DataTable
		da1.Fill(dt1)

		ComboBox3.ValueMember = "t1"
		ComboBox3.DisplayMember = "t1"
		ComboBox3.DataSource = dt1


		myConn.Close()

	End Sub
	Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
		Dim myConn As New SqlConnection(app_con_str)
		myConn.Open()

		Dim da1 As New SqlDataAdapter("select distinct(convert(varchar,EXPIRY_DT,106)) t1,EXPIRY_DT from fo_bhavcopy where SYMBOL='" & ComboBox1.SelectedValue & "' and INSTRUMENT in ('OPTSTK','OPTIDX') and EXPIRY_DT>=GETDATE() order by t1", myConn)
		Dim dt1 As New DataTable
		da1.Fill(dt1)

		ComboBox2.ValueMember = "EXPIRY_DT"
		ComboBox2.DisplayMember = "t1"
		ComboBox2.DataSource = dt1

	End Sub

	Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
		If RadioButton1.Checked Then
			RadioButton2.Checked = False
		Else
			RadioButton2.Checked = True
		End If
	End Sub

	Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
		If RadioButton2.Checked Then
			RadioButton1.Checked = False
			ComboBox1.Enabled = True
		Else
			RadioButton1.Checked = True
			ComboBox1.Enabled = False
		End If
	End Sub

	Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
		Try
			Me.Fo_bhavcopyTableAdapter.FillBy(Me.BhavcopyDataSet1.fo_bhavcopy)
		Catch ex As System.Exception
			System.Windows.Forms.MessageBox.Show(ex.Message)
		End Try

	End Sub

	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

		Dim excelPath_src = Directory.GetCurrentDirectory()
		Dim excelPath_name = "\NiftyPremium-Decay.xlsx"


		If System.IO.File.Exists(excelPath_src & "\NiftyPremium-Decay_new.xlsx") = True Then
			System.IO.File.Delete(excelPath_src & "\NiftyPremium-Decay_new.xlsx")
		End If

		Dim file = New FileInfo(excelPath_src & "\" & excelPath_name)
		file.CopyTo(Path.Combine(excelPath_src, "NiftyPremium-Decay_new.xlsx"), True)

		xlApp = New Excel.Application
		xlWorkBook = xlApp.Workbooks.Open(excelPath_src & "\" & "NiftyPremium-Decay_new.xlsx")           ' WORKBOOK TO OPEN THE EXCEL FILE.
		xlApp.Visible = True
		xlWorkSheet = xlWorkBook.Worksheets("Sheet3")    ' THE NAME OF THE WORK SHEET. 

		Dim con As New SqlConnection
		con.ConnectionString = app_con_str
		con.Open()

		Dim expiryMth = DateAndTime.Month(ComboBox2.SelectedValue)

		Dim strSQL = "select top 4 * from fo_bhavcopy where cast(TIMESTAMP as date)='" & DateTimePicker2.Value & "'"
		strSQL = strSQL & " and INSTRUMENT in ('OPTIDX','OPTSTK')  and Month(EXPIRY_DT)=" & expiryMth & " "
		strSQL = strSQL & " And symbol ='" & ComboBox1.SelectedValue & "' and OPTION_TYP='CE' order by OPEN_INT desc"

		Dim cmd1 As New SqlCommand(strSQL, con)
		Dim rd1 As SqlDataReader = cmd1.ExecuteReader

		Dim i As Integer
		i = 3
		While rd1.Read()
			xlWorkSheet.Cells(5, i) = rd1("OPEN_INT").ToString()
			xlWorkSheet.Cells(6, i) = rd1("STRIKE_PR").ToString()
			i = i + 1
		End While
		rd1.Close()

		strSQL = "select top 4 * from fo_bhavcopy where cast(TIMESTAMP as date)='" & DateTimePicker2.Value & "'"
		strSQL = strSQL & " and INSTRUMENT in ('OPTIDX','OPTSTK')   and Month(EXPIRY_DT)=" & expiryMth & ""
		strSQL = strSQL & " And symbol ='" & ComboBox1.SelectedValue & "' and OPTION_TYP='PE' order by OPEN_INT desc"

		Dim cmd2 As New SqlCommand(strSQL, con)
		Dim rd2 As SqlDataReader = cmd2.ExecuteReader

		i = 8
		While rd2.Read()
			xlWorkSheet.Cells(5, i) = rd2("OPEN_INT").ToString()
			xlWorkSheet.Cells(6, i) = rd2("STRIKE_PR").ToString()
			i = i + 1
		End While
		rd2.Close()

		strSQL = "select distinct(STRIKE_PR) as STRIKE_PR from fo_bhavcopy where cast(TIMESTAMP as date)='" & DateTimePicker2.Value & "'"
		strSQL = strSQL & " and INSTRUMENT in ('OPTIDX','OPTSTK')   and Month(EXPIRY_DT)=" & expiryMth & ""
		strSQL = strSQL & " And symbol ='" & ComboBox1.SelectedValue & "' order by STRIKE_PR asc"

		Dim cmd3 As New SqlCommand(strSQL, con)
		Dim rd3 As SqlDataReader = cmd3.ExecuteReader

		Dim strike_range = 8
		i = 8
		While rd3.Read()
			xlWorkSheet.Cells(i, 2) = rd3("STRIKE_PR").ToString()
			strike_range = strike_range + 1
			i = i + 1
		End While
		rd2.Close()

		Dim totalDays = DateDiff(DateInterval.Day, DateTimePicker1.Value, DateTimePicker2.Value) + 1
		Dim startDate = DateTimePicker1.Value
		Dim currDate = startDate


		For k As Integer = 1 To totalDays
			If Not (currDate.DayOfWeek = DayOfWeek.Saturday Or currDate.DayOfWeek = DayOfWeek.Sunday) Then


				strSQL = "SELECT TOP (1) * "
				strSQL = strSQL & " FROM ( "
				strSQL = strSQL & " select distinct(STRIKE_PR) as t1 from fo_bhavcopy where cast(TIMESTAMP as date)='" & DateTimePicker2.Value & "' and SYMBOL='" & ComboBox1.SelectedValue & "'"
				strSQL = strSQL & " and INSTRUMENT in ('OPTSTK','OPTIDX')   and Month(EXPIRY_DT)=" & expiryMth & " "
				strSQL = strSQL & " ) as t3"
				strSQL = strSQL & " ORDER BY ABS(t1-(select [close] from bhavcopy where cast(TIMESTAMP as date)='" & currDate & "' and SYMBOL='" & ComboBox1.SelectedValue & "'))"


				Dim cmd4 As New SqlCommand(strSQL, con)
				Dim rd4 As SqlDataReader = cmd4.ExecuteReader

				While rd4.Read()

					Dim row_1 = 1
					Dim col_1 = 3


					For j As Integer = 8 To strike_range

						If xlWorkSheet.Cells(j, 2).Value = rd4("t1") Then
							row_1 = j
						End If

					Next

					If k = totalDays Then
						xlWorkSheet.Cells(row_1, 1) = "ATM"
					End If
					strSQL = "select top 4 SETTLE_PR from fo_bhavcopy where cast(TIMESTAMP as date)='" & currDate & "' and INSTRUMENT in ('OPTSTK','OPTIDX') and SYMBOL='" & ComboBox1.SelectedValue & "' and OPTION_TYP='CE' and Month(EXPIRY_DT)=" & expiryMth & " order by OPEN_INT desc"
					Dim cmd5 As New SqlCommand(strSQL, con)
					Dim rd5 As SqlDataReader = cmd5.ExecuteReader
					While rd5.Read()
						xlWorkSheet.Cells(row_1, col_1) = rd5("SETTLE_PR")
						col_1 = col_1 + 1
					End While

					col_1 = col_1 + 1
					strSQL = "select top 4 SETTLE_PR from fo_bhavcopy where cast(TIMESTAMP as date)='" & currDate & "' and INSTRUMENT in ('OPTSTK','OPTIDX') and SYMBOL='" & ComboBox1.SelectedValue & "' and OPTION_TYP='PE' and Month(EXPIRY_DT)=" & expiryMth & " order by OPEN_INT desc"
					Dim cmd6 As New SqlCommand(strSQL, con)
					Dim rd6 As SqlDataReader = cmd6.ExecuteReader
					While rd6.Read()
						xlWorkSheet.Cells(row_1, col_1) = rd6("SETTLE_PR")
						col_1 = col_1 + 1
					End While


					strSQL = "select [close] as c1 from bhavcopy where cast(TIMESTAMP as date)='" & currDate & "' and SYMBOL='" & ComboBox1.SelectedValue & "'"
					Dim cmd7 As New SqlCommand(strSQL, con)
					Dim rd7 As SqlDataReader = cmd7.ExecuteReader
					While rd7.Read()
						xlWorkSheet.Cells(row_1, col_1) = rd7("c1")

					End While

					i = i + 1
				End While
				rd4.Close()



			End If
			currDate = DateAdd("d", 1, currDate)
		Next
		MsgBox("Premium Decay done")
	End Sub

End Class